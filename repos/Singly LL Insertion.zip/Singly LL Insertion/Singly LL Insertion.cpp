
#include <iostream>
using namespace std;
class Node
{
    int data;
    Node* next;
public:
    Node()
    {
        data = 0;
        next = NULL;
    }
    Node(int x)
    {
        data = x;
        next = NULL;
    }
    int getdata()
    {
        return data;
    }
    Node* getnext()
    {
        return next;
    }
    void setnext(Node* x)
    {
        next = x;
    }
};
class Linked_List
{
    Node* head;
public:
    Linked_List()
    {
        head = NULL;
    }
    Linked_List(int x)
    {
        head = new Node(x);
    }
    void insertnode(int x)
    {
        auto newnode = new Node(x);
        Node* temp;
        if (head == NULL)
            head = newnode;
        for (temp = head; temp->getnext() != NULL; temp = temp->getnext());
        temp->setnext(newnode);
    }
    void insertnode(int pos, int x)
    {
        Node* temp;
        int count;
        Node* newnode = new Node(x);
        if (pos == 0)
        {
            newnode->setnext(head);
            head = newnode;
            return;
        }
        for (temp = head, count =1 ; count < pos; temp = temp->getnext(),count++);
        
        newnode->setnext(temp->getnext());
        temp->setnext(newnode);

    }
    void deletenode(int pos)
    {
        int length = 0;
        Node* prev = head;
        Node* temp;
        int count;
        for (temp = head; temp != NULL; temp = temp->getnext())
        {
            length++;
        }
        if (pos > length||pos<0)
        {
            cout << "Invalid Position Sent. ";
            exit(1);
        }
        else if (pos == 0)
        {
            temp = head;
            head = head->getnext();
            delete temp;
            return;
        }
        for (temp = head, count = 1; count < pos; count++, temp = temp->getnext())
        {
            prev = temp;
        }
        prev->setnext(temp->getnext());
        delete temp;

    }
    void display()
    {
        int i = 0;
        for (auto temp = head; temp != NULL; temp = temp->getnext())
        {
            cout <<i+1<<" Node: " << temp->getdata() << endl;
            i++;
        }
    }
    void reverse()
    {
        Node* prev;
        Node* cur;
        Node* next;
        prev = 0;
        cur = head;
        next = head;
        while (next != NULL)
        {
            next = next->getnext();
            cur->setnext(prev);
            prev=cur;
            cur = next;
        }
        head = prev;

    }
};
int main()
{
    Linked_List l1(1);
    l1.insertnode(2);
    l1.insertnode(4);
    l1.insertnode(5);
    l1.insertnode(0, 3);
    l1.insertnode(4, 6);
    
    l1.display();
    l1.deletenode(5);
    l1.display();
    cout << endl << endl;
    l1.reverse();
    l1.display();
}
